public class Main {
    public static void main(String[] args) {


        suma s0 = new suma(0,10);
        suma s1 = new suma(11,20);
        suma s2 = new suma(21,30);
        suma s3 = new suma(31,40);
        suma s4 = new suma(41,50);
        suma s5 = new suma(51,60);
        suma s6 = new suma(61,70);
        suma s7 = new suma(71,80);
        suma s8 = new suma(81,90);
        suma s9 = new suma(91,100);

        s0.run();
        s1.run();
        s2.run();
        s3.run();
        s4.run();
        s5.run();
        s6.run();
        s7.run();
        s8.run();
        s9.run();

        try{
            s0.join();
            s1.join();
            s2.join();
            s3.join();
            s4.join();
            s5.join();
            s6.join();
            s7.join();
            s8.join();
            s9.join();





        }catch (Exception e)
        {
            System.out.println(s0);
            System.out.println(s1);
            System.out.println(s2);
            System.out.println(s3);
            System.out.println(s4);
            System.out.println(s5);
            System.out.println(s6);
            System.out.println(s7);
            System.out.println(s8);
            System.out.println(s9);

        }


    }
}