public class suma extends Thread{



    int przedzial;
    int licznik;

    public suma(int liczby, int licznik) {
        this.przedzial = liczby;
        this.licznik = licznik;
    }

    public void run()
    {
        int suma = 0;
        double srednia = 0;
        double dzielnik = 10;
        for(int i = przedzial; i<=licznik; i++)
        {
            przedzial++;
            suma+=i;
            if(i==licznik)
            {
                srednia = suma/dzielnik;
            }
        }
        System.out.println("suma = " + suma);
        System.out.println("srednia = " + srednia);
        srednia = 0;
    }



}
